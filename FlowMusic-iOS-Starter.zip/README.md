# Flow Music iOS starter

This is a **new SwiftUI iOS starter project** inspired by the features described in the Flow Music Android repository. It is not a converted APK and it is not yet a finished replacement for the Android app.

## Included in this starter
- Native SwiftUI layout for iPhone
- Import audio files from the iOS Files picker
- Local audio playback and pause/stop controls
- Search within the imported library
- Liked songs stored locally
- Basic Home / Liked / Playlists navigation shell

## Not included yet
- Streaming service/API integration
- Automatic next/previous, shuffle, repeat, seek bar, queue management
- Full playlist creation and editing
- Now Playing lock-screen metadata and remote controls
- Final app icon, launch screen, accessibility review, testing, and release signing

## Build requirement
You need a macOS build environment with Xcode to compile a native iOS app. This project includes an Xcode project, so it can be opened by Xcode or built by a macOS CI runner.

## Phone-only workflow outline
1. Upload the contents of this folder to a **new GitHub repository** (or place it in a separate branch; do not overwrite your Android project).
2. Use a hosted macOS runner to build and test the project.
3. To install on a physical iPhone, configure Apple signing and provisioning with your own Apple account. Do not share Apple passwords or signing certificates with anyone.
4. Test playback with audio files you own or are licensed to use.

## Privacy
Imported audio files are copied into the app's private Documents directory. This starter does not upload audio files anywhere.

import SwiftUI
import UniformTypeIdentifiers

struct Track: Identifiable, Hashable {
    let id: UUID
    let url: URL
    var title: String
    var isFavorite: Bool = false

    init(url: URL, title: String? = nil, isFavorite: Bool = false) {
        self.id = UUID()
        self.url = url
        self.title = title ?? url.deletingPathExtension().lastPathComponent
        self.isFavorite = isFavorite
    }
}

struct ContentView: View {
    @StateObject private var player = MusicPlayer()
    @State private var searchText = ""
    @State private var showingImporter = false
    @State private var selectedTab = 0

    private var visibleTracks: [Track] {
        let tracks = selectedTab == 1 ? player.tracks.filter(\.isFavorite) : player.tracks
        guard !searchText.isEmpty else { return tracks }
        return tracks.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            if selectedTab == 2 {
                playlistsPlaceholder
            } else {
                libraryContent
            }
            if player.currentTrack != nil {
                miniPlayer
            }
            tabBar
        }
        .background(Color(red: 0.97, green: 0.97, blue: 0.98))
        .fileImporter(
            isPresented: $showingImporter,
            allowedContentTypes: [.audio, .mp3, .mpeg4Audio, .wav],
            allowsMultipleSelection: true,
            onCompletion: handleImport
        )
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                HStack(spacing: 9) {
                    Image(systemName: "waveform")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 42, height: 42)
                        .background(Color.indigo, in: RoundedRectangle(cornerRadius: 13))
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Flow Music").font(.title2.bold())
                        Text("Your music, your flow").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer()
                Button { showingImporter = true } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.indigo)
                        .frame(width: 42, height: 42)
                        .background(.white, in: Circle())
                }
                .accessibilityLabel("Import music")
            }

            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Search your library", text: $searchText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            .padding(12)
            .background(.white, in: RoundedRectangle(cornerRadius: 14))
        }
        .padding(.horizontal, 20)
        .padding(.top, 18)
        .padding(.bottom, 14)
        .background(Color(red: 0.97, green: 0.97, blue: 0.98))
    }

    private var libraryContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(selectedTab == 1 ? "Liked Songs" : "Your Library")
                            .font(.title3.bold())
                        Text("\(visibleTracks.count) tracks")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { showingImporter = true } label: {
                        Label("Add music", systemImage: "plus")
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.indigo)
                }

                if visibleTracks.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "music.note.list")
                            .font(.system(size: 38))
                            .foregroundStyle(.indigo)
                        Text(searchText.isEmpty ? "Your library is waiting" : "No matching songs")
                            .font(.headline)
                        Text(searchText.isEmpty
                             ? "Tap Add music to choose audio files stored in the Files app."
                             : "Try another song title.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 55)
                } else {
                    VStack(spacing: 0) {
                        ForEach(visibleTracks) { track in
                            trackRow(track)
                            if track.id != visibleTracks.last?.id {
                                Divider().padding(.leading, 58)
                            }
                        }
                    }
                    .padding(.horizontal, 12)
                    .background(.white, in: RoundedRectangle(cornerRadius: 18))
                }
            }
            .padding(20)
        }
    }

    private func trackRow(_ track: Track) -> some View {
        HStack(spacing: 12) {
            Button { player.play(track) } label: {
                HStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 11)
                        .fill(Color.indigo.opacity(0.1))
                        .frame(width: 44, height: 44)
                        .overlay {
                            Image(systemName: player.currentTrack?.id == track.id && player.isPlaying
                                  ? "waveform" : "music.note")
                                .foregroundStyle(.indigo)
                        }
                    VStack(alignment: .leading, spacing: 4) {
                        Text(track.title)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                        Text(player.currentTrack?.id == track.id ? "Now playing" : "Audio file")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 2)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Button { player.toggleFavorite(track) } label: {
                Image(systemName: track.isFavorite ? "heart.fill" : "heart")
                    .foregroundStyle(track.isFavorite ? .pink : .secondary)
                    .padding(8)
            }
            .accessibilityLabel(track.isFavorite ? "Unlike song" : "Like song")
        }
        .padding(.vertical, 9)
    }

    private var miniPlayer: some View {
        HStack(spacing: 12) {
            Image(systemName: "waveform")
                .foregroundStyle(.white)
                .frame(width: 42, height: 42)
                .background(Color.indigo, in: RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 3) {
                Text(player.currentTrack?.title ?? "Nothing playing")
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                Text(player.isPlaying ? "Playing from your library" : "Paused")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button { player.togglePlayback() } label: {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.title3)
                    .foregroundStyle(.primary)
                    .frame(width: 38, height: 42)
            }
            Button { player.stop() } label: {
                Image(systemName: "stop.fill")
                    .foregroundStyle(.secondary)
                    .frame(width: 30, height: 42)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.white)
        .overlay(alignment: .top) { Divider() }
    }

    private var tabBar: some View {
        HStack {
            tabButton("house.fill", title: "Home", tab: 0)
            tabButton("heart.fill", title: "Liked", tab: 1)
            tabButton("music.note.list", title: "Playlists", tab: 2)
        }
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(.white)
        .overlay(alignment: .top) { Divider() }
    }

    private func tabButton(_ symbol: String, title: String, tab: Int) -> some View {
        Button { selectedTab = tab } label: {
            VStack(spacing: 5) {
                Image(systemName: symbol).font(.system(size: 18, weight: .semibold))
                Text(title).font(.caption2.weight(.medium))
            }
            .foregroundStyle(selectedTab == tab ? .indigo : .secondary)
            .frame(maxWidth: .infinity)
        }
    }

    private var playlistsPlaceholder: some View {
        VStack(spacing: 12) {
            Image(systemName: "music.note.list")
                .font(.system(size: 40))
                .foregroundStyle(.indigo)
            Text("Playlists").font(.title2.bold())
            Text("Playlist creation is planned for the next version.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(30)
    }

    private func handleImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            for url in urls {
                let granted = url.startAccessingSecurityScopedResource()
                defer { if granted { url.stopAccessingSecurityScopedResource() } }
                do {
                    let destination = try player.copyIntoAppStorage(url)
                    player.addTrack(at: destination)
                } catch {
                    player.lastError = "Couldn't import \(url.lastPathComponent): \(error.localizedDescription)"
                }
            }
        case .failure(let error):
            player.lastError = error.localizedDescription
        }
    }
}

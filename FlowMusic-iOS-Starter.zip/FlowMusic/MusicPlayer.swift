import Foundation
import AVFoundation
import SwiftUI

@MainActor
final class MusicPlayer: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published private(set) var currentTrack: Track?
    @Published private(set) var isPlaying = false
    @Published var lastError: String?

    private var audioPlayer: AVAudioPlayer?
    private let folderName = "ImportedMusic"

    init() {
        configureAudioSession()
        loadTracks()
    }

    func addTrack(at url: URL) {
        guard !tracks.contains(where: { $0.url == url }) else { return }
        tracks.append(Track(url: url))
        saveTrackList()
    }

    func play(_ track: Track) {
        do {
            if currentTrack?.id == track.id, let audioPlayer {
                audioPlayer.play()
                isPlaying = true
                return
            }
            let player = try AVAudioPlayer(contentsOf: track.url)
            player.prepareToPlay()
            player.play()
            audioPlayer = player
            currentTrack = track
            isPlaying = true
        } catch {
            lastError = "Unable to play this file. Try an MP3, M4A, or WAV file."
            isPlaying = false
        }
    }

    func togglePlayback() {
        guard let audioPlayer else { return }
        if audioPlayer.isPlaying {
            audioPlayer.pause()
            isPlaying = false
        } else {
            audioPlayer.play()
            isPlaying = true
        }
    }

    func stop() {
        audioPlayer?.stop()
        audioPlayer = nil
        currentTrack = nil
        isPlaying = false
    }

    func toggleFavorite(_ track: Track) {
        guard let index = tracks.firstIndex(where: { $0.url == track.url }) else { return }
        tracks[index].isFavorite.toggle()
        saveTrackList()
    }

    func copyIntoAppStorage(_ source: URL) throws -> URL {
        let fm = FileManager.default
        let directory = try musicDirectory()
        let destination = directory.appendingPathComponent(source.lastPathComponent)
        if fm.fileExists(atPath: destination.path) {
            let stem = source.deletingPathExtension().lastPathComponent
            let ext = source.pathExtension
            let unique = "\(stem)-\(UUID().uuidString.prefix(6)).\(ext)"
            let alternate = directory.appendingPathComponent(unique)
            try fm.copyItem(at: source, to: alternate)
            return alternate
        }
        try fm.copyItem(at: source, to: destination)
        return destination
    }

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            lastError = "Audio setup failed: \(error.localizedDescription)"
        }
    }

    private func musicDirectory() throws -> URL {
        let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let directory = root.appendingPathComponent(folderName, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory
    }

    private var indexURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("flow_tracks.json")
    }

    private struct SavedTrack: Codable {
        let filename: String
        let title: String
        let isFavorite: Bool
    }

    private func saveTrackList() {
        let saved = tracks.map {
            SavedTrack(filename: $0.url.lastPathComponent, title: $0.title, isFavorite: $0.isFavorite)
        }
        do {
            let data = try JSONEncoder().encode(saved)
            try data.write(to: indexURL, options: .atomic)
        } catch {
            lastError = "Couldn't save your library."
        }
    }

    private func loadTracks() {
        guard let data = try? Data(contentsOf: indexURL),
              let saved = try? JSONDecoder().decode([SavedTrack].self, from: data),
              let directory = try? musicDirectory() else { return }
        tracks = saved.compactMap { item in
            let url = directory.appendingPathComponent(item.filename)
            guard FileManager.default.fileExists(atPath: url.path) else { return nil }
            return Track(url: url, title: item.title, isFavorite: item.isFavorite)
        }
    }
}
